# Assignment - 1, 2, 3

* *Name: Rishabh Ravindran*
  * Registraion number: 20BKT0097
  * Gmail: rishabh.ravindran2020@vitstudent.ac.in
  * Phone number: 9052989913
