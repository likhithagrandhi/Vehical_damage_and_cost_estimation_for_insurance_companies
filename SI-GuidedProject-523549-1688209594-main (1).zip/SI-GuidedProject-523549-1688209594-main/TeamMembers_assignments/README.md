# Team members Assignments - 1, 2, 3
This repository contains the Assignments allocated by the SmartBridge externship program. It encompasses Assignment 1, Assignment 2, and Assignment 3 of the following team members:

* *Name: Rishabh Ravindran*
  * Registraion number: 20BKT0097
  * Gmail: rishabh.ravindran2020@vitstudent.ac.in
  * Phone number: 9052989913

* *Name: Tejeswar Reddy*
  * Registraion number: 20BKT0123
  * Gmail: busireddy.tejeswar2020@vitstudent.ac.in
  * Phone number: 7892861310

* *Name: Kanala Harika*
  * Registraion number: 20BKT0101
  * Gmail: kanalaharika.reddy2020@vitstudent.ac.in
  * Phone number: 9701681161

* *Name: Aniket Kulkarni*
  * Registraion number: 20BRS1038
  * Gmail: aniketashok.kulkarni2020@vitstudent.ac.in
  * Phone number: 8308137820
