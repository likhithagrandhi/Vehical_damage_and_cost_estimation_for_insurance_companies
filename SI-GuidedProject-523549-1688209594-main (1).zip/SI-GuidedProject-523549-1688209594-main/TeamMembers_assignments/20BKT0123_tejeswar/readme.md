# Assignment - 1, 2, 3
* *Name: Tejeswar Reddy*
  * Registraion number: 20BKT0123
  * Gmail: busireddy.tejeswar2020@vitstudent.ac.in
  * Phone number: 7892861310
