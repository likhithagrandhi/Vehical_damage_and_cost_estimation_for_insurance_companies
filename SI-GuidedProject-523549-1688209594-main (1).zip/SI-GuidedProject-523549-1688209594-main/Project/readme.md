# Intelligent vehicle damage and cost estimation

## Folder Structure

<pre><font color="#12488B"><b>.</b></font>
├── <font color="#12488B"><b>Flask_app</b></font>
└── <font color="#12488B"><b>IPYNB Files</b></font>
</pre>

This folder contains the following structure:

* *Flask_app*: Contains the code implementation and files required to run the Flask Application.
* *IPYNB Files*:  This folder contains the IPYNB files that were used for training our models.
\
